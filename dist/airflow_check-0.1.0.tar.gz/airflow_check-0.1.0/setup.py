# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['airflow_check', 'airflow_check.airflow_check']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'airflow-check',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Chad Upjohn',
    'author_email': 'cupjohn@condati.com',
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
